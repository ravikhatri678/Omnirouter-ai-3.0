package com.example.network

/**
 * Intelligent Endpoint Discovery & Resolution Engine.
 * Automatically resolves and constructs correct API endpoints, protocols, and model identifiers
 * based solely on the user's API Key and provider type, eliminating the need for manual endpoint configuration.
 */
object EndpointResolver {

    data class ResolvedEndpoint(
        val providerId: String,
        val providerName: String,
        val baseUrl: String,
        val completionUrl: String,
        val authHeaderType: AuthType,
        val protocol: ApiProtocol,
        val isSelfDiscovered: Boolean = true
    )

    enum class AuthType {
        BEARER,
        QUERY_PARAM_KEY,
        X_API_KEY
    }

    enum class ApiProtocol {
        OPENAI_COMPATIBLE,
        GOOGLE_GEMINI,
        ANTHROPIC_MESSAGES
    }

    /**
     * Auto-detects provider identifier from the API Key prefix or pattern.
     */
    fun detectProviderFromKey(key: String): String {
        val trimmed = key.trim()
        return when {
            trimmed.startsWith("AIza", ignoreCase = false) -> "google"
            trimmed.startsWith("sk-ant-", ignoreCase = false) -> "anthropic"
            trimmed.startsWith("sk-or-", ignoreCase = false) -> "openrouter"
            trimmed.startsWith("gsk_", ignoreCase = false) -> "groq"
            trimmed.startsWith("deepseek-", ignoreCase = false) -> "deepseek"
            trimmed.startsWith("sk-proj-", ignoreCase = false) || trimmed.startsWith("sk-", ignoreCase = false) -> "openai"
            else -> "openrouter" // Default universal aggregator
        }
    }

    /**
     * Self-discovers and resolves the exact API endpoint configuration for a provider.
     */
    fun resolveEndpoint(providerId: String, apiKey: String = ""): ResolvedEndpoint {
        val effectiveProviderId = if (apiKey.isNotBlank() && providerId == "custom") {
            detectProviderFromKey(apiKey)
        } else {
            providerId.lowercase()
        }

        return when (effectiveProviderId) {
            "google" -> ResolvedEndpoint(
                providerId = "google",
                providerName = "Google AI Studio",
                baseUrl = "https://generativelanguage.googleapis.com/v1beta/",
                completionUrl = "https://generativelanguage.googleapis.com/v1beta/models/",
                authHeaderType = AuthType.QUERY_PARAM_KEY,
                protocol = ApiProtocol.GOOGLE_GEMINI
            )
            "openai" -> ResolvedEndpoint(
                providerId = "openai",
                providerName = "OpenAI",
                baseUrl = "https://api.openai.com/v1/",
                completionUrl = "https://api.openai.com/v1/chat/completions",
                authHeaderType = AuthType.BEARER,
                protocol = ApiProtocol.OPENAI_COMPATIBLE
            )
            "anthropic" -> ResolvedEndpoint(
                providerId = "anthropic",
                providerName = "Anthropic",
                baseUrl = "https://api.anthropic.com/v1/",
                completionUrl = "https://api.anthropic.com/v1/messages",
                authHeaderType = AuthType.X_API_KEY,
                protocol = ApiProtocol.ANTHROPIC_MESSAGES
            )
            "openrouter" -> ResolvedEndpoint(
                providerId = "openrouter",
                providerName = "OpenRouter Universal",
                baseUrl = "https://openrouter.ai/api/v1/",
                completionUrl = "https://openrouter.ai/api/v1/chat/completions",
                authHeaderType = AuthType.BEARER,
                protocol = ApiProtocol.OPENAI_COMPATIBLE
            )
            "groq" -> ResolvedEndpoint(
                providerId = "groq",
                providerName = "Groq High-Speed",
                baseUrl = "https://api.groq.com/openai/v1/",
                completionUrl = "https://api.groq.com/openai/v1/chat/completions",
                authHeaderType = AuthType.BEARER,
                protocol = ApiProtocol.OPENAI_COMPATIBLE
            )
            "deepseek" -> ResolvedEndpoint(
                providerId = "deepseek",
                providerName = "DeepSeek AI",
                baseUrl = "https://api.deepseek.com/v1/",
                completionUrl = "https://api.deepseek.com/v1/chat/completions",
                authHeaderType = AuthType.BEARER,
                protocol = ApiProtocol.OPENAI_COMPATIBLE
            )
            "ollama" -> ResolvedEndpoint(
                providerId = "ollama",
                providerName = "Ollama Local",
                baseUrl = "http://10.0.2.2:11434/v1/",
                completionUrl = "http://10.0.2.2:11434/v1/chat/completions",
                authHeaderType = AuthType.BEARER,
                protocol = ApiProtocol.OPENAI_COMPATIBLE
            )
            else -> ResolvedEndpoint(
                providerId = effectiveProviderId,
                providerName = effectiveProviderId.replaceFirstChar { it.uppercase() },
                baseUrl = "https://openrouter.ai/api/v1/",
                completionUrl = "https://openrouter.ai/api/v1/chat/completions",
                authHeaderType = AuthType.BEARER,
                protocol = ApiProtocol.OPENAI_COMPATIBLE
            )
        }
    }

    /**
     * Resolves wire model identifier for cross-provider universal execution.
     * Accurately adapts any model identifier to the target provider's native model format.
     */
    fun resolveModelIdentifier(modelId: String, wireIdentifier: String, targetProviderId: String): String {
        val cleanIdentifier = wireIdentifier.substringAfter("/")
        return when (targetProviderId) {
            "openrouter" -> {
                when {
                    wireIdentifier.contains("/") -> wireIdentifier
                    modelId.contains("/") -> modelId
                    cleanIdentifier.startsWith("gemini") -> "google/$cleanIdentifier"
                    cleanIdentifier.startsWith("claude") -> "anthropic/$cleanIdentifier"
                    cleanIdentifier.startsWith("gpt") || cleanIdentifier.startsWith("o1") || cleanIdentifier.startsWith("o3") -> "openai/$cleanIdentifier"
                    cleanIdentifier.startsWith("deepseek") -> "deepseek/$cleanIdentifier"
                    cleanIdentifier.startsWith("llama") -> "meta-llama/$cleanIdentifier"
                    else -> wireIdentifier
                }
            }
            "google" -> {
                when {
                    cleanIdentifier.contains("pro") || cleanIdentifier.contains("opus") || cleanIdentifier.contains("sonnet") || cleanIdentifier.contains("o1") || cleanIdentifier.contains("o3") -> "gemini-3.1-pro-preview"
                    cleanIdentifier.contains("flash-lite") || cleanIdentifier.contains("lite") -> "gemini-3.1-flash-lite-preview"
                    cleanIdentifier.contains("flash") -> "gemini-3.5-flash"
                    cleanIdentifier.startsWith("gemini-") -> cleanIdentifier
                    else -> "gemini-3.5-flash"
                }
            }
            "openai" -> {
                when {
                    cleanIdentifier.startsWith("o1") -> "o1"
                    cleanIdentifier.startsWith("o3") -> "o3-mini"
                    cleanIdentifier.contains("mini") || cleanIdentifier.contains("haiku") || cleanIdentifier.contains("flash") || cleanIdentifier.contains("8b") -> "gpt-4o-mini"
                    cleanIdentifier.startsWith("gpt-") -> cleanIdentifier
                    else -> "gpt-4o"
                }
            }
            "anthropic" -> {
                when {
                    cleanIdentifier.contains("3-7") || cleanIdentifier.contains("3.7") -> "claude-3-7-sonnet-20250219"
                    cleanIdentifier.contains("haiku") || cleanIdentifier.contains("mini") || cleanIdentifier.contains("flash") -> "claude-3-5-haiku-20241022"
                    cleanIdentifier.contains("opus") -> "claude-3-opus-20240229"
                    cleanIdentifier.startsWith("claude-") -> cleanIdentifier
                    else -> "claude-3-5-sonnet-20241022"
                }
            }
            "groq" -> {
                when {
                    cleanIdentifier.contains("r1") || cleanIdentifier.contains("reason") -> "deepseek-r1-distill-llama-70b"
                    cleanIdentifier.contains("8b") || cleanIdentifier.contains("mini") || cleanIdentifier.contains("flash") -> "llama-3.1-8b-instant"
                    cleanIdentifier.startsWith("llama-") || cleanIdentifier.startsWith("deepseek-") -> cleanIdentifier
                    else -> "llama-3.3-70b-versatile"
                }
            }
            "deepseek" -> {
                when {
                    cleanIdentifier.contains("r1") || cleanIdentifier.contains("reason") -> "deepseek-reasoner"
                    else -> "deepseek-chat"
                }
            }
            else -> cleanIdentifier
        }
    }
}
